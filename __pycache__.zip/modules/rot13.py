def rot13(text):
    def shift_char(char):
        base = ord('A') if char.isupper() else ord('a')
        return chr((ord(char) - base + 13) % 26 + base)
    
    result = ""
    for char in text:
        if char.isalpha():
            result += shift_char(char)
        else:
            result += char
    
    return result
